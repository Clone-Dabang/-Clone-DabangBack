package jpabook.jpashop.test;


import com.fasterxml.jackson.core.JsonProcessingException;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class TestController{

    private final CustomJsonPassing customJsonPassing;



    @PostMapping("/api/test")
    public void test(@RequestBody RawRequestDto rawRequestDto)  throws JsonProcessingException {




        RequestJson requestJson = customJsonPassing.jasonPassingUsingGson(rawRequestDto);
        RequestJson.AddressInfoDetail saveAddressDto = new RequestJson.AddressInfoDetail();






    }
}